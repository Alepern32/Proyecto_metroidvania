import { updateAI } from "../ai/EnemyAI";
import HpBar from "../ui/HpBar";

export default class Enemy {

  // ── Crea y configura un enemigo en la escena ──────────────────────────────
  static spawn(scene, x, eData) {
    if (!eData) return null;

    const nombre = eData.nombre;

    const texKey = "enemy-" + nombre.replace(/ /g, "_");
    const texValida = scene.textures.exists(texKey) && scene.textures.get(texKey).frameTotal > 1;
    const textureKey = texValida ? texKey : "enemy-slime";
    const fallback = textureKey === "enemy-slime";

    const enemy = scene.enemies.create(x, 800, textureKey);
    if (!enemy) return null;

    enemy.setCollideWorldBounds(true);

    // ── Hitbox según tipo + checkCollision.up = false para saltar bajo plataformas ──
    if (nombre === "slime") {
      enemy.body.setSize(20, 14);
      enemy.body.setOffset(6, 0);
    } else if (nombre === "murcielago") {
      enemy.body.setSize(24, 16);
      enemy.body.setOffset(4, 8);
      enemy.body.allowGravity = false;
      // El murciélago vuela, no necesita checkCollision.up
    } else if (nombre === "planta saltarina") {
      enemy.body.setSize(20, 28);
      enemy.body.setOffset(6, 4);
    } else {
      enemy.body.setSize(20, 20);
    }

    // ── Stats leídos del JSON de enemigos ────────────────────────────────
    enemy.tipo        = nombre;
    enemy.hp          = eData.estadisticas?.vida       || 20;
    enemy.hpMax       = enemy.hp;
    enemy.danioAtaque = eData.estadisticas?.danio      || 5;
    enemy.defensa     = eData.estadisticas?.defensa    || 1;
    enemy.velocidad   = eData.estadisticas?.velocidad  || 60;
    enemy.xpReward    = eData.estadisticas?.experiencia || 10;
    enemy.moneyDrop   = eData.drop?.dinero             || 5;
    enemy.dropProb    = eData.drop?.probabilidad       ?? 1;

    enemy.dir         = Math.random() > 0.5 ? 1 : -1;
    enemy.patrolTimer = 0;
    enemy.jumpTimer   = 0;
    enemy.chaseDist   = nombre === "murcielago" ? 250 : 180;

    // ── Barra de vida flotante ───────────────────────────────────────────
    const hpBar = new HpBar(scene);

    enemy.updateHpBar = () => {
      if (!enemy.active) return;
      const pct = Math.max(0, enemy.hp / enemy.hpMax);
      hpBar.update(enemy.x, enemy.y, pct);
    };

    const origDestroy = enemy.destroy.bind(enemy);
    enemy.destroy = () => {
      hpBar.destroy();
      origDestroy();
    };

    if (fallback) enemy.tipo = "slime";
    const animKey = fallback ? "slime-move" : Enemy.animMove(nombre);
    if (scene.anims.exists(animKey)) enemy.play(animKey);

    return enemy;
  }

  static animMove(nombre) {
    if (nombre === "slime")            return "slime-move";
    if (nombre === "murcielago")       return "bat-fly";
    if (nombre === "planta saltarina") return "plant-move";
    return "slime-move";
  }

  static animHurt(nombre) {
    if (nombre === "slime")            return "slime-hurt";
    if (nombre === "murcielago")       return "bat-hurt";
    if (nombre === "planta saltarina") return "plant-hurt";
    return "slime-hurt";
  }

  static updateAI(enemy, player, delta) {
    updateAI(enemy, player, delta);
  }
}