// ── IA de enemigos  ─────────────────────────────

export function updateAI(enemy, player, delta) {
  if (!enemy.active) return;

  const dx = Math.abs(enemy.x - player.x);
  const dy = Math.abs(enemy.y - player.y);

  if (enemy.tipo === "slime") {
    if (dy < 40 && dx < enemy.chaseDist) {
      const dir = player.x > enemy.x ? 1 : -1;
      enemy.setVelocityX(enemy.velocidad * dir);
      enemy.setFlipX(dir > 0);
    } else {
      enemy.patrolTimer += delta;
      if (enemy.patrolTimer > 2000) { enemy.dir *= -1; enemy.patrolTimer = 0; }
      enemy.setVelocityX(enemy.velocidad * 0.4 * enemy.dir);
      enemy.setFlipX(enemy.dir > 0);
    }

  } else if (enemy.tipo === "murcielago") {
    if (dx < enemy.chaseDist) {
      const dirX = player.x > enemy.x ? 1 : -1;
      const dirY = player.y > enemy.y ? 1 : -1;
      enemy.setVelocityX(enemy.velocidad * dirX);
      enemy.setVelocityY(enemy.velocidad * 0.6 * dirY);
      enemy.setFlipX(dirX > 0);
    } else {
      enemy.patrolTimer += delta;
      if (enemy.patrolTimer > 1500) { enemy.dir *= -1; enemy.patrolTimer = 0; }
      enemy.setVelocityX(enemy.velocidad * 0.3 * enemy.dir);
      enemy.setVelocityY(Math.sin(enemy.patrolTimer * 0.002) * 30);
    }

  } else if (enemy.tipo === "planta saltarina") {
    enemy.jumpTimer += delta;
    const onGround = enemy.body.blocked.down;

    if (dx < enemy.chaseDist) {
      const dir = player.x > enemy.x ? 1 : -1;
      enemy.setVelocityX(enemy.velocidad * 0.5 * dir);
      enemy.setFlipX(dir > 0);
      if (onGround && enemy.jumpTimer > 1200) { enemy.setVelocityY(-500); enemy.jumpTimer = 0; }
    } else {
      enemy.patrolTimer += delta;
      if (enemy.patrolTimer > 2500) { enemy.dir *= -1; enemy.patrolTimer = 0; }
      enemy.setVelocityX(enemy.velocidad * 0.3 * enemy.dir);
      if (onGround && enemy.jumpTimer > 2000) { enemy.setVelocityY(-380); enemy.jumpTimer = 0; }
    }
  }
}