// ── Guardado y carga de partida en localStorage ───────────────────────────

const SAVE_KEY = "partidaGuardada";

export const SaveManager = {
  load() {
    const raw = localStorage.getItem(SAVE_KEY);
    return raw ? JSON.parse(raw) : null;
  },

  save(player, score) {
    const estado = {
      vida:      player.hp,
      vidaMax:   player.hpMax,
      oro:       score,
      nivel:     player.nivel,
      xp:        player.xp,
      danioBase: player.danioBase,
      defensa:   player.defensa,
      posicionX: Math.round(player.x),
      posicionY: Math.round(player.y),
    };
    localStorage.setItem(SAVE_KEY, JSON.stringify(estado));
    console.log("✅ Partida guardada:", estado);
  },
};